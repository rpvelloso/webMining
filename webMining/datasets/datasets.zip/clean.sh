#!/bin/bash

rm -rf ./clustvx/srde
rm -rf ./alvarez/srde
rm -rf ./tpsf/srde
rm -rf ./trieschnigg1/srde
rm -rf ./trieschnigg2/srde
rm -rf ./wien/srde
rm -rf ./yamada/srde
rm -rf ./zhao1/srde
rm -rf ./zhao2/srde
rm -rf ./zhao3/srde

mkdir ./clustvx/srde
mkdir ./alvarez/srde
mkdir ./tpsf/srde
mkdir ./trieschnigg1/srde
mkdir ./trieschnigg2/srde
mkdir ./wien/srde
mkdir ./yamada/srde
mkdir ./zhao1/srde
mkdir ./zhao2/srde
mkdir ./zhao3/srde